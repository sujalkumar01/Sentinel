import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import Header from "@/components/Header";
import { Activity, MapPin, AlertTriangle, CheckCircle2, Clock, TrendingUp } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from "recharts";

const Dashboard = () => {
  const [searchValue, setSearchValue] = useState("");

  // Mock data for charts
  const overallTrendsData = [
    { date: "Jan 1", total: 156, alerts: 2 },
    { date: "Jan 8", total: 187, alerts: 4 },
    { date: "Jan 15", total: 203, alerts: 1 },
    { date: "Jan 22", total: 234, alerts: 6 },
    { date: "Jan 29", total: 267, alerts: 3 },
  ];

  const regionData = [
    { region: "Delhi Airport", vehicles: 47, status: "normal" },
    { region: "Mumbai Port", vehicles: 89, status: "elevated" },
    { region: "Chennai Base", vehicles: 23, status: "normal" },
    { region: "Bangalore Tech", vehicles: 156, status: "high" },
  ];

  const recentAlerts = [
    { 
      id: 1, 
      type: "warning", 
      location: "Mumbai Port", 
      message: "+15 vehicles detected", 
      time: "2 hours ago",
      severity: "medium"
    },
    { 
      id: 2, 
      type: "success", 
      location: "Delhi Airport", 
      message: "Pattern normalized", 
      time: "4 hours ago",
      severity: "low"
    },
    { 
      id: 3, 
      type: "alert", 
      location: "Bangalore Tech", 
      message: "Unusual activity spike", 
      time: "6 hours ago",
      severity: "high"
    },
    { 
      id: 4, 
      type: "success", 
      location: "Chennai Base", 
      message: "Scan completed", 
      time: "8 hours ago",
      severity: "low"
    },
  ];

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high': return 'text-destructive';
      case 'medium': return 'text-warning';
      default: return 'text-success';
    }
  };

  const getSeverityIcon = (type: string) => {
    switch (type) {
      case 'alert':
      case 'warning':
        return AlertTriangle;
      default:
        return CheckCircle2;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header 
        searchValue={searchValue} 
        onSearchChange={setSearchValue} 
        onSearch={() => {}} 
      />
      
      <main className="pt-20 px-6 pb-8">
        <div className="max-w-7xl mx-auto space-y-8">
          
          {/* Header */}
          <div className="flex items-center gap-4">
            <Activity className="w-8 h-8 text-primary" />
            <div>
              <h1 className="text-3xl font-bold text-foreground">Intelligence Dashboard</h1>
              <p className="text-muted-foreground">Global monitoring and analysis overview</p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            
            {/* Left column - Charts */}
            <div className="lg:col-span-2 space-y-6">
              
              {/* Overall trends */}
              <Card className="bg-card border-border">
                <CardHeader>
                  <CardTitle className="text-foreground flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-primary" />
                    Global Detection Trends
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={overallTrendsData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                        <XAxis 
                          dataKey="date" 
                          stroke="hsl(var(--muted-foreground))"
                          fontSize={12}
                        />
                        <YAxis 
                          stroke="hsl(var(--muted-foreground))"
                          fontSize={12}
                        />
                        <Tooltip 
                          contentStyle={{
                            backgroundColor: "hsl(var(--popover))",
                            border: "1px solid hsl(var(--border))",
                            borderRadius: "6px",
                            color: "hsl(var(--popover-foreground))"
                          }}
                        />
                        <Line 
                          type="monotone" 
                          dataKey="total" 
                          stroke="hsl(var(--primary))" 
                          strokeWidth={3}
                          name="Total Detections"
                        />
                        <Line 
                          type="monotone" 
                          dataKey="alerts" 
                          stroke="hsl(var(--destructive))" 
                          strokeWidth={2}
                          name="Alerts"
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              {/* Regional overview */}
              <Card className="bg-card border-border">
                <CardHeader>
                  <CardTitle className="text-foreground flex items-center gap-2">
                    <MapPin className="w-5 h-5 text-primary" />
                    Regional Activity
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={regionData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                        <XAxis 
                          dataKey="region" 
                          stroke="hsl(var(--muted-foreground))"
                          fontSize={12}
                        />
                        <YAxis 
                          stroke="hsl(var(--muted-foreground))"
                          fontSize={12}
                        />
                        <Tooltip 
                          contentStyle={{
                            backgroundColor: "hsl(var(--popover))",
                            border: "1px solid hsl(var(--border))",
                            borderRadius: "6px",
                            color: "hsl(var(--popover-foreground))"
                          }}
                        />
                        <Bar 
                          dataKey="vehicles" 
                          fill="hsl(var(--primary))" 
                          name="Vehicle Count"
                        />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              {/* Heat map placeholder */}
              <Card className="bg-card border-border">
                <CardHeader>
                  <CardTitle className="text-foreground">Global Activity Map</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="aspect-video bg-muted rounded-lg flex items-center justify-center relative overflow-hidden">
                    <div className="text-muted-foreground text-center">
                      <MapPin className="w-12 h-12 mx-auto mb-2 opacity-50" />
                      <p>Interactive global heatmap</p>
                      <p className="text-sm">Scan locations and activity levels</p>
                    </div>
                    {/* Mock heatmap dots */}
                    <div className="absolute top-1/3 left-1/4 w-4 h-4 bg-primary rounded-full opacity-70 animate-pulse"></div>
                    <div className="absolute top-1/2 right-1/3 w-3 h-3 bg-warning rounded-full opacity-60 animate-pulse"></div>
                    <div className="absolute bottom-1/3 left-1/2 w-5 h-5 bg-destructive rounded-full opacity-80 animate-pulse"></div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Right column - Alerts feed */}
            <div className="space-y-6">
              
              {/* Quick stats */}
              <div className="grid grid-cols-2 gap-4">
                <Card className="bg-card border-border">
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold text-primary">267</div>
                    <div className="text-xs text-muted-foreground">Total Detections</div>
                  </CardContent>
                </Card>
                <Card className="bg-card border-border">
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold text-destructive">3</div>
                    <div className="text-xs text-muted-foreground">Active Alerts</div>
                  </CardContent>
                </Card>
              </div>

              {/* Alerts feed */}
              <Card className="bg-card border-border">
                <CardHeader>
                  <CardTitle className="text-foreground flex items-center gap-2">
                    <AlertTriangle className="w-5 h-5 text-warning" />
                    Recent Alerts
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  <div className="space-y-1">
                    {recentAlerts.map((alert) => {
                      const IconComponent = getSeverityIcon(alert.type);
                      return (
                        <div key={alert.id} className="p-4 hover:bg-muted/50 transition-colors border-b border-border last:border-0">
                          <div className="flex items-start gap-3">
                            <IconComponent className={`w-4 h-4 mt-0.5 ${getSeverityColor(alert.severity)}`} />
                            <div className="flex-1 space-y-1">
                              <div className="flex items-center justify-between">
                                <span className="text-sm font-medium text-foreground">{alert.location}</span>
                                <Badge 
                                  variant={alert.severity === 'high' ? 'destructive' : 'secondary'}
                                  className="text-xs"
                                >
                                  {alert.severity}
                                </Badge>
                              </div>
                              <p className="text-xs text-muted-foreground">{alert.message}</p>
                              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                                <Clock className="w-3 h-3" />
                                {alert.time}
                              </div>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>

              {/* System status */}
              <Card className="bg-card border-border">
                <CardHeader>
                  <CardTitle className="text-foreground">System Status</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-foreground">Detection Model</span>
                    <Badge className="bg-success text-success-foreground">Online</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-foreground">Satellite Feed</span>
                    <Badge className="bg-success text-success-foreground">Active</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-foreground">AI Analysis</span>
                    <Badge className="bg-success text-success-foreground">Running</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-foreground">Last Update</span>
                    <span className="text-xs text-muted-foreground">2 min ago</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Dashboard;