import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import Header from "@/components/Header";
import { FileText, TrendingUp, MapPin, Calendar } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

const Analysis = () => {
  const [searchValue, setSearchValue] = useState("");

  // Mock data for the chart
  const chartData = [
    { date: "Jan 15", total: 32, cars: 20, trucks: 8, tanks: 2, aircraft: 2 },
    { date: "Jan 20", total: 38, cars: 23, trucks: 10, tanks: 2, aircraft: 3 },
    { date: "Jan 25", total: 45, cars: 25, trucks: 12, tanks: 3, aircraft: 5 },
    { date: "Jan 30", total: 47, cars: 23, trucks: 12, tanks: 3, aircraft: 9 },
  ];

  const aiSummary = `Intelligence Analysis Report - Delhi Airport Region

Vehicle activity analysis reveals significant patterns in the Delhi Airport vicinity. Over the past 15 days, total vehicle count has increased by 47% from baseline levels, indicating heightened operational activity.

Key Observations:
• Civilian vehicle presence has stabilized at 23 units, suggesting normal airport operations
• Heavy vehicle (truck) count increased by 50%, potentially indicating increased cargo operations
• Military vehicle presence remains minimal with 3 armored units detected
• Aircraft count surge of 350% observed, correlating with seasonal travel patterns

Risk Assessment: LOW
The observed increases appear consistent with normal seasonal aviation activity and increased cargo operations typical for this time period. No anomalous military buildup detected.

Recommendations:
• Continue monitoring for any deviation from established patterns
• Alert threshold: >15% increase in military vehicles within 48-hour period
• Next scan recommended in 72 hours to maintain situational awareness`;

  return (
    <div className="min-h-screen bg-background animate-fade-in">
      <Header 
        searchValue={searchValue} 
        onSearchChange={setSearchValue} 
        onSearch={() => {}} 
      />
      
      <main className="pt-20 px-6 pb-8">
        <div className="max-w-6xl mx-auto space-y-8">
          
          {/* Header */}
          <div className="flex items-center gap-4">
            <FileText className="w-8 h-8 text-primary" />
            <div>
              <h1 className="text-3xl font-bold text-foreground">Intelligence Analysis</h1>
              <p className="text-muted-foreground">AI-generated situation report and trends</p>
            </div>
          </div>

          {/* Detection Image */}
          <Card className="bg-card border-border">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-foreground flex items-center gap-2">
                  <MapPin className="w-5 h-5 text-primary" />
                  Detection Overview
                </CardTitle>
                <Badge variant="secondary" className="text-success">
                  <Calendar className="w-4 h-4 mr-1" />
                  Latest Scan
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="relative aspect-video bg-muted rounded-lg overflow-hidden">
                <img 
                  src="/placeholder.svg" 
                  alt="Satellite image with detections"
                  className="w-full h-full object-cover"
                />
                {/* Enhanced bounding boxes with labels */}
                <div className="absolute top-12 left-16">
                  <div className="w-8 h-6 border-2 border-primary bg-primary/20 relative">
                    <span className="absolute -top-6 left-0 text-xs bg-primary text-primary-foreground px-1 rounded">CAR</span>
                  </div>
                </div>
                <div className="absolute top-20 left-32">
                  <div className="w-12 h-8 border-2 border-accent bg-accent/20 relative">
                    <span className="absolute -top-6 left-0 text-xs bg-accent text-accent-foreground px-1 rounded">TRUCK</span>
                  </div>
                </div>
                <div className="absolute bottom-16 right-20">
                  <div className="w-6 h-4 border-2 border-warning bg-warning/20 relative">
                    <span className="absolute -top-6 left-0 text-xs bg-warning text-warning-foreground px-1 rounded">TANK</span>
                  </div>
                </div>
                <div className="absolute bottom-24 left-24">
                  <div className="w-10 h-6 border-2 border-info bg-info/20 relative">
                    <span className="absolute -top-6 left-0 text-xs bg-info text-info-foreground px-1 rounded">AIRCRAFT</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* AI Analysis Report */}
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="text-foreground flex items-center gap-2">
                <FileText className="w-5 h-5 text-primary" />
                AI Intelligence Summary
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="prose prose-invert max-w-none">
                <pre className="whitespace-pre-wrap text-sm text-foreground font-mono leading-relaxed bg-muted p-4 rounded-lg">
                  {aiSummary}
                </pre>
              </div>
            </CardContent>
          </Card>

          {/* Trends Chart */}
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="text-foreground flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-primary" />
                Activity Trends
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis 
                      dataKey="date" 
                      stroke="hsl(var(--muted-foreground))"
                      fontSize={12}
                    />
                    <YAxis 
                      stroke="hsl(var(--muted-foreground))"
                      fontSize={12}
                    />
                    <Tooltip 
                      contentStyle={{
                        backgroundColor: "hsl(var(--popover))",
                        border: "1px solid hsl(var(--border))",
                        borderRadius: "6px",
                        color: "hsl(var(--popover-foreground))"
                      }}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="total" 
                      stroke="hsl(var(--primary))" 
                      strokeWidth={3}
                      name="Total Vehicles"
                    />
                    <Line 
                      type="monotone" 
                      dataKey="cars" 
                      stroke="hsl(var(--accent))" 
                      strokeWidth={2}
                      name="Cars"
                    />
                    <Line 
                      type="monotone" 
                      dataKey="trucks" 
                      stroke="hsl(var(--warning))" 
                      strokeWidth={2}
                      name="Trucks"
                    />
                    <Line 
                      type="monotone" 
                      dataKey="aircraft" 
                      stroke="hsl(var(--info))" 
                      strokeWidth={2}
                      name="Aircraft"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
};

export default Analysis;