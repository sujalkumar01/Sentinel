import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import Header from "@/components/Header";
import { Search, Save, MapPin, Clock, Car, Truck, Shield, Plane, AlertTriangle, CheckCircle2 } from "lucide-react";

const Results = () => {
  const navigate = useNavigate();
  const [searchValue, setSearchValue] = useState("");

  // Mock data for demonstration
  const scanData = {
    location: "Delhi Airport",
    coordinates: "28.5562, 77.1000",
    timestamp: new Date().toLocaleString(),
    image: "/placeholder.svg", // Mock satellite image
    detections: {
      total: 47,
      cars: 23,
      trucks: 12,
      tanks: 3,
      aircraft: 9
    },
    alerts: [
      { type: "warning", message: "+7 vehicles added", icon: AlertTriangle },
      { type: "success", message: "3 tanks removed", icon: CheckCircle2 }
    ]
  };

  const handleDetailedAnalysis = () => {
    navigate("/analysis");
  };

  const handleSaveScan = () => {
    // Save scan logic would go here
    console.log("Scan saved");
  };

  return (
    <div className="min-h-screen bg-background">
      <Header 
        searchValue={searchValue} 
        onSearchChange={setSearchValue} 
        onSearch={() => {}} 
      />
      
      <main className="pt-20 px-6 pb-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col lg:flex-row gap-8">
            
            {/* Left side - Main image */}
            <div className="flex-1">
              <Card className="bg-card border-border">
                <CardHeader>
                  <CardTitle className="text-foreground flex items-center gap-2">
                    <MapPin className="w-5 h-5 text-primary" />
                    Satellite Analysis
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="relative aspect-video bg-muted rounded-lg overflow-hidden">
                    <img 
                      src="/placeholder.svg" 
                      alt="Satellite image with detections"
                      className="w-full h-full object-cover"
                    />
                    {/* Mock bounding boxes */}
                    <div className="absolute top-12 left-16 w-8 h-6 border-2 border-primary bg-primary/20"></div>
                    <div className="absolute top-20 left-32 w-12 h-8 border-2 border-accent bg-accent/20"></div>
                    <div className="absolute bottom-16 right-20 w-6 h-4 border-2 border-warning bg-warning/20"></div>
                    <div className="absolute bottom-24 left-24 w-10 h-6 border-2 border-info bg-info/20"></div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Right side - Analysis panel */}
            <div className="lg:w-96 space-y-6">
              
              {/* Summary section */}
              <Card className="bg-card border-border">
                <CardHeader>
                  <CardTitle className="text-foreground">Summary</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-sm">
                      <MapPin className="w-4 h-4 text-primary" />
                      <span className="text-foreground font-medium">{scanData.location}</span>
                    </div>
                    <div className="text-xs text-muted-foreground">{scanData.coordinates}</div>
                  </div>
                  
                  <div className="flex items-center gap-2 text-sm">
                    <Clock className="w-4 h-4 text-muted-foreground" />
                    <span className="text-muted-foreground">{scanData.timestamp}</span>
                  </div>
                </CardContent>
              </Card>

              {/* Counts section */}
              <Card className="bg-card border-border">
                <CardHeader>
                  <CardTitle className="text-foreground">Detection Counts</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-primary">{scanData.detections.total}</div>
                    <div className="text-sm text-muted-foreground">Total Objects</div>
                  </div>
                  
                  <Separator className="bg-border" />
                  
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Car className="w-4 h-4 text-primary" />
                        <span className="text-sm text-foreground">Cars</span>
                      </div>
                      <Badge variant="secondary">{scanData.detections.cars}</Badge>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Truck className="w-4 h-4 text-accent" />
                        <span className="text-sm text-foreground">Trucks</span>
                      </div>
                      <Badge variant="secondary">{scanData.detections.trucks}</Badge>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Shield className="w-4 h-4 text-warning" />
                        <span className="text-sm text-foreground">Tanks</span>
                      </div>
                      <Badge variant="secondary">{scanData.detections.tanks}</Badge>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Plane className="w-4 h-4 text-info" />
                        <span className="text-sm text-foreground">Aircraft</span>
                      </div>
                      <Badge variant="secondary">{scanData.detections.aircraft}</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Alerts section */}
              <Card className="bg-card border-border">
                <CardHeader>
                  <CardTitle className="text-foreground">Alerts</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {scanData.alerts.map((alert, index) => {
                    const IconComponent = alert.icon;
                    const colorClass = alert.type === 'warning' ? 'text-warning' : 'text-success';
                    return (
                      <div key={index} className="flex items-center gap-3 p-3 rounded-lg bg-muted">
                        <IconComponent className={`w-5 h-5 ${colorClass}`} />
                        <span className="text-sm text-foreground">{alert.message}</span>
                      </div>
                    );
                  })}
                </CardContent>
              </Card>

              {/* Action buttons */}
              <div className="space-y-3">
                <Button 
                  onClick={handleDetailedAnalysis}
                  className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
                >
                  <Search className="w-4 h-4 mr-2" />
                  Detailed Analysis
                </Button>
                
                <Button 
                  onClick={handleSaveScan}
                  variant="outline"
                  className="w-full border-border text-foreground hover:bg-accent hover:text-accent-foreground"
                >
                  <Save className="w-4 h-4 mr-2" />
                  Save Scan
                </Button>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Results;