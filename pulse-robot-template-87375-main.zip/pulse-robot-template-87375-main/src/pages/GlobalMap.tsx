import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import Header from "@/components/Header";
import Globe from "@/components/Globe";
import ProcessingOverlay from "@/components/ProcessingOverlay";
import { Upload, Target, Camera } from "lucide-react";

const GlobalMap = () => {
  const navigate = useNavigate();
  const [searchLocation, setSearchLocation] = useState("");
  const [isUploadMode, setIsUploadMode] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [coordinates, setCoordinates] = useState("");

  const handleCapture = () => {
    setIsProcessing(true);
    // Simulate processing time
    setTimeout(() => {
      setIsProcessing(false);
      navigate("/results");
    }, 3000);
  };

  const handleAnalyzeImage = () => {
    if (!uploadedFile) return;
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      navigate("/results");
    }, 3000);
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setUploadedFile(file);
    }
  };

  const handleLocationSearch = () => {
    // Globe rotation logic would go here
    console.log("Searching for:", searchLocation);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header searchValue={searchLocation} onSearchChange={setSearchLocation} onSearch={handleLocationSearch} />
      
      <main className="relative h-screen pt-16 overflow-hidden">
        {/* Mode Toggle */}
        <div className="absolute top-6 left-6 z-20">
          <Card className="bg-card/80 backdrop-blur-sm">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <Target className="w-5 h-5 text-primary" />
                <span className="text-sm font-medium text-foreground">Globe Mode</span>
                <Switch
                  checked={isUploadMode}
                  onCheckedChange={setIsUploadMode}
                />
                <Upload className="w-5 h-5 text-accent" />
                <span className="text-sm font-medium text-foreground">Upload Mode</span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Globe Component */}
        <div className={`transition-all duration-500 ${isUploadMode ? 'blur-sm opacity-50' : ''}`}>
          <Globe />
        </div>

        {/* Globe Mode Controls */}
        {!isUploadMode && (
          <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-20">
            <Button
              onClick={handleCapture}
              size="lg"
              className="bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg px-8 py-4 text-lg"
            >
              <Camera className="w-6 h-6 mr-2" />
              Capture & Analyze
            </Button>
          </div>
        )}

        {/* Upload Mode Controls */}
        {isUploadMode && (
          <div className="absolute inset-0 flex items-center justify-center z-20">
            <Card className="w-full max-w-md bg-card/90 backdrop-blur-sm">
              <CardContent className="p-8 space-y-6">
                <div className="text-center">
                  <Upload className="w-12 h-12 text-accent mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-foreground mb-2">
                    Upload Satellite Image
                  </h3>
                  <p className="text-muted-foreground text-sm">
                    Upload an aerial/satellite image to analyze
                  </p>
                </div>

                <div className="border-2 border-dashed border-border rounded-lg p-8 text-center hover:border-primary transition-colors">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleFileUpload}
                    className="hidden"
                    id="file-upload"
                  />
                  <label htmlFor="file-upload" className="cursor-pointer">
                    <div className="text-muted-foreground">
                      {uploadedFile ? (
                        <div className="space-y-2">
                          <Badge variant="secondary" className="text-success">
                            {uploadedFile.name}
                          </Badge>
                          <p className="text-xs">Click to change file</p>
                        </div>
                      ) : (
                        <div className="space-y-2">
                          <p className="text-sm">Click to upload or drag and drop</p>
                          <p className="text-xs">PNG, JPG, GIF up to 10MB</p>
                        </div>
                      )}
                    </div>
                  </label>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground">
                    Coordinates (optional)
                  </label>
                  <Input
                    placeholder="e.g., 28.6139, 77.2090"
                    value={coordinates}
                    onChange={(e) => setCoordinates(e.target.value)}
                    className="bg-input border-border text-foreground"
                  />
                </div>

                <Button
                  onClick={handleAnalyzeImage}
                  disabled={!uploadedFile}
                  className="w-full bg-accent hover:bg-accent/90 text-accent-foreground"
                  size="lg"
                >
                  <Target className="w-5 h-5 mr-2" />
                  Analyze Image
                </Button>
              </CardContent>
            </Card>
          </div>
        )}
      </main>

      {isProcessing && <ProcessingOverlay />}
    </div>
  );
};

export default GlobalMap;